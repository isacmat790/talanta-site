import type { CSSProperties } from "react";
import { createFileRoute } from "@tanstack/react-router";
import capturedCSS from "../styles/pages/events.bayern-munich-vs-ajax.css?raw";

export const Route = createFileRoute("/events_/bayern-munich-vs-ajax")({
  head: () => ({ meta: [{ title: "Bayern Munich vs Ajax - Talanta Sports City" }] }),
  staticData: { importedDocument: { html: { "lang": "en-US" }, body: {  } } },
  component: Index,
});

function Index() {
  return (
    <>
      <style>{capturedCSS}</style>
      <div className="wp-site-blocks">
        <div className="entry-content is-layout-flow flow-root">
          <div className="bks max-w-full overflow-hidden" id="bks-1">
            <header className="bks-head items-center flex">
              <a className="bks-back grid flex-none place-items-center [transition:background_0.2s]" aria-label="Go back" href="/">
                <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M15 5l-7 7 7 7" />
                </svg>
              </a>
              <img className="bks-hero block flex-none object-cover" src="/site-assets/2950f7ef83df7589.png" alt="" />
              <div className="bks-ht min-w-0">
                <h2>Bayern Munich vs Ajax</h2>
                <p>Tue 5 Jan 2027 · 11:00 · Raila Odinga International Stadium, Nairobi</p>
              </div>
            </header>
            <div className="bks-body grid gap-4">
              <div className="bks-map min-h-[520px] relative">
                <svg className="bks-svg cursor-grab block h-full min-h-[520px] touch-none w-full" viewBox="0 0 1000 800">
                  <defs>
                    <pattern id="hatchbks-1" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
                      <rect width="6" height="6" fill="#9a9ca6" />
                      <rect width="2" height="6" fill="#555762" />
                    </pattern>
                  </defs>
                  <g className="pitch">
                    <rect x="370" y="320" width="260" height="160" rx="4" />
                    <line x1="500" y1="320" x2="500" y2="480" />
                    <circle cx="500" cy="400" r="28" />
                    <rect x="370" y="365" width="30" height="70" />
                    <rect x="600" y="365" width="30" height="70" />
                  </g>
                  <g>
                    <g className="sec available" tabIndex={0}>
                      <title>101 · Level 1 · 1 left · KSh 2,500</title>
                      <path d="M505.9,193.0L525.6,193.1L541.2,193.5L555.1,194.0L567.9,194.7L580.0,195.7L591.5,196.8L575.6,232.1L566.1,231.2L556.1,230.4L545.5,229.8L534.0,229.4L521.2,229.1L504.9,229.0Z" />
                      <text className="lg fill-white pointer-events-none" x="550.2727075824376" y="215.91481289053476" textAnchor="middle">101</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>102 · Level 1 · 3 left · KSh 2,500</title>
                      <path d="M595.3,197.2L606.1,198.6L616.5,200.2L626.5,202.0L636.2,204.0L645.5,206.2L654.6,208.5L627.7,241.8L620.2,239.9L612.5,238.1L604.5,236.4L596.3,235.0L587.7,233.6L578.7,232.5Z" />
                      <text className="lg fill-white pointer-events-none" x="615.536045646476" y="223.21258241014277" textAnchor="middle">102</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>103 · Level 1 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M657.6,209.4L666.2,212.0L674.6,214.9L682.6,217.9L690.4,221.1L697.9,224.5L705.1,228.1L669.4,258.0L663.4,255.0L657.3,252.2L650.8,249.5L644.2,247.1L637.3,244.7L630.2,242.5Z" />
                      <text className="lg fill-white pointer-events-none" x="666.7216275064621" y="237.7051859952375" textAnchor="middle">103</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>104 · Level 1 · 1 left · KSh 2,500</title>
                      <path d="M707.5,229.3L714.4,233.2L721.0,237.2L727.3,241.4L733.3,245.8L739.1,250.4L744.6,255.2L702.1,280.4L697.5,276.5L692.7,272.7L687.7,269.0L682.5,265.5L677.1,262.2L671.4,259.0Z" />
                      <text className="lg fill-white pointer-events-none" x="707.5048431011577" y="259.2291792317505" textAnchor="middle">104</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>105 · Level 1 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M746.4,256.9L751.6,262.0L756.5,267.2L761.1,272.6L765.4,278.2L769.4,284.0L773.2,290.0L725.7,309.2L722.6,304.2L719.2,299.4L715.7,294.8L711.9,290.3L707.8,286.0L703.6,281.8Z" />
                      <text className="lg fill-white pointer-events-none" x="738.3559000734929" y="287.6825854606078" textAnchor="middle">105</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>106 · Level 1 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M774.4,292.2L777.8,298.5L781.0,305.0L783.8,311.7L786.4,318.7L788.6,326.0L790.6,333.5L740.1,345.1L738.4,338.8L736.6,332.8L734.4,327.1L732.1,321.5L729.5,316.1L726.7,310.9Z" />
                      <text className="lg fill-white pointer-events-none" x="759.1286318787954" y="323.3934565257144" textAnchor="middle">106</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>107 · Level 1 · 3 left · KSh 2,500</title>
                      <path d="M791.3,336.2L792.9,344.2L794.2,352.6L795.3,361.6L796.0,371.3L796.5,382.1L796.7,395.9L745.1,396.6L744.9,385.2L744.5,376.3L743.9,368.3L743.0,360.9L741.9,353.9L740.6,347.3Z" />
                      <text className="lg fill-white pointer-events-none" x="769.5887681902336" y="368.92601796574115" textAnchor="middle">107</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>108 · Level 1 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M796.7,404.1L796.5,417.9L796.0,428.7L795.3,438.4L794.2,447.4L792.9,455.8L791.3,463.8L740.6,452.7L741.9,446.1L743.0,439.1L743.9,431.7L744.5,423.7L744.9,414.8L745.1,403.4Z" />
                      <text className="lg fill-white pointer-events-none" x="769.5887681902336" y="439.07398203425885" textAnchor="middle">108</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>109 · Level 1 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M790.6,466.5L788.6,474.0L786.4,481.3L783.8,488.3L781.0,495.0L777.8,501.5L774.4,507.8L726.7,489.1L729.5,483.9L732.1,478.5L734.4,472.9L736.6,467.2L738.4,461.2L740.1,454.9Z" />
                      <text className="lg fill-white pointer-events-none" x="759.1286318787954" y="484.6065434742857" textAnchor="middle">109</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>110 · Level 1 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M773.2,510.0L769.4,516.0L765.4,521.8L761.1,527.4L756.5,532.8L751.6,538.0L746.4,543.1L703.6,518.2L707.8,514.0L711.9,509.7L715.7,505.2L719.2,500.6L722.6,495.8L725.7,490.8Z" />
                      <text className="lg fill-white pointer-events-none" x="738.3559000734929" y="520.3174145393922" textAnchor="middle">110</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>111 · Level 1 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M744.6,544.8L739.1,549.6L733.3,554.2L727.3,558.6L721.0,562.8L714.4,566.8L707.5,570.7L671.4,541.0L677.1,537.8L682.5,534.5L687.7,531.0L692.7,527.3L697.5,523.5L702.1,519.6Z" />
                      <text className="lg fill-white pointer-events-none" x="707.5048431011577" y="548.7708207682495" textAnchor="middle">111</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>112 · Level 1 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M705.1,571.9L697.9,575.5L690.4,578.9L682.6,582.1L674.6,585.1L666.2,588.0L657.6,590.6L630.2,557.5L637.3,555.3L644.2,552.9L650.8,550.5L657.3,547.8L663.4,545.0L669.4,542.0Z" />
                      <text className="lg fill-white pointer-events-none" x="666.7216275064621" y="570.2948140047625" textAnchor="middle">112</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>113 · Level 1 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M654.6,591.5L645.5,593.8L636.2,596.0L626.5,598.0L616.5,599.8L606.1,601.4L595.3,602.8L578.7,567.5L587.7,566.4L596.3,565.0L604.5,563.6L612.5,561.9L620.2,560.1L627.7,558.2Z" />
                      <text className="lg fill-white pointer-events-none" x="615.536045646476" y="584.7874175898572" textAnchor="middle">113</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>114 · Level 1 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M591.5,603.2L580.0,604.3L567.9,605.3L555.1,606.0L541.2,606.5L525.6,606.9L505.9,607.0L504.9,571.0L521.2,570.9L534.0,570.6L545.5,570.2L556.1,569.6L566.1,568.8L575.6,567.9Z" />
                      <text className="lg fill-white pointer-events-none" x="550.2727075824376" y="592.0851871094652" textAnchor="middle">114</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>115 · Level 1 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M494.1,607.0L474.4,606.9L458.8,606.5L444.9,606.0L432.1,605.3L420.0,604.3L408.5,603.2L424.4,567.9L433.9,568.8L443.9,569.6L454.5,570.2L466.0,570.6L478.8,570.9L495.1,571.0Z" />
                      <text className="lg fill-white pointer-events-none" x="449.72729241756224" y="592.0851871094652" textAnchor="middle">115</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>116 · Level 1 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M404.7,602.8L393.9,601.4L383.5,599.8L373.5,598.0L363.8,596.0L354.5,593.8L345.4,591.5L372.3,558.2L379.8,560.1L387.5,561.9L395.5,563.6L403.7,565.0L412.3,566.4L421.3,567.5Z" />
                      <text className="lg fill-white pointer-events-none" x="384.4639543535239" y="584.7874175898572" textAnchor="middle">116</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>117 · Level 1 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M342.4,590.6L333.8,588.0L325.4,585.1L317.4,582.1L309.6,578.9L302.1,575.5L294.9,571.9L330.6,542.0L336.6,545.0L342.7,547.8L349.2,550.5L355.8,552.9L362.7,555.3L369.8,557.5Z" />
                      <text className="lg fill-white pointer-events-none" x="333.27837249353786" y="570.2948140047625" textAnchor="middle">117</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>118 · Level 1 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M292.5,570.7L285.6,566.8L279.0,562.8L272.7,558.6L266.7,554.2L260.9,549.6L255.4,544.8L297.9,519.6L302.5,523.5L307.3,527.3L312.3,531.0L317.5,534.5L322.9,537.8L328.6,541.0Z" />
                      <text className="lg fill-white pointer-events-none" x="292.49515689884237" y="548.7708207682496" textAnchor="middle">118</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>119 · Level 1 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M253.6,543.1L248.4,538.0L243.5,532.8L238.9,527.4L234.6,521.8L230.6,516.0L226.8,510.0L274.3,490.8L277.4,495.8L280.8,500.6L284.3,505.2L288.1,509.7L292.2,514.0L296.4,518.2Z" />
                      <text className="lg fill-white pointer-events-none" x="261.6440999265071" y="520.3174145393922" textAnchor="middle">119</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>120 · Level 1 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M225.6,507.8L222.2,501.5L219.0,495.0L216.2,488.3L213.6,481.3L211.4,474.0L209.4,466.5L259.9,454.9L261.6,461.2L263.4,467.2L265.6,472.9L267.9,478.5L270.5,483.9L273.3,489.1Z" />
                      <text className="lg fill-white pointer-events-none" x="240.87136812120463" y="484.6065434742857" textAnchor="middle">120</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>121 · Level 1 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M208.7,463.8L207.1,455.8L205.8,447.4L204.7,438.4L204.0,428.7L203.5,417.9L203.3,404.1L254.9,403.4L255.1,414.8L255.5,423.7L256.1,431.7L257.0,439.1L258.1,446.1L259.4,452.7Z" />
                      <text className="lg fill-white pointer-events-none" x="230.4112318097665" y="439.07398203425896" textAnchor="middle">121</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>122 · Level 1 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M203.3,395.9L203.5,382.1L204.0,371.3L204.7,361.6L205.8,352.6L207.1,344.2L208.7,336.2L259.4,347.3L258.1,353.9L257.0,360.9L256.1,368.3L255.5,376.3L255.1,385.2L254.9,396.6Z" />
                      <text className="lg fill-white pointer-events-none" x="230.41123180976643" y="368.9260179657412" textAnchor="middle">122</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>123 · Level 1 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M209.4,333.5L211.4,326.0L213.6,318.7L216.2,311.7L219.0,305.0L222.2,298.5L225.6,292.2L273.3,310.9L270.5,316.1L267.9,321.5L265.6,327.1L263.4,332.8L261.6,338.8L259.9,345.1Z" />
                      <text className="lg fill-white pointer-events-none" x="240.87136812120463" y="323.3934565257144" textAnchor="middle">123</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>124 · Level 1 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M226.8,290.0L230.6,284.0L234.6,278.2L238.9,272.6L243.5,267.2L248.4,262.0L253.6,256.9L296.4,281.8L292.2,286.0L288.1,290.3L284.3,294.8L280.8,299.4L277.4,304.2L274.3,309.2Z" />
                      <text className="lg fill-white pointer-events-none" x="261.6440999265071" y="287.68258546060775" textAnchor="middle">124</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>125 · Level 1 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M255.4,255.2L260.9,250.4L266.7,245.8L272.7,241.4L279.0,237.2L285.6,233.2L292.5,229.3L328.6,259.0L322.9,262.2L317.5,265.5L312.3,269.0L307.3,272.7L302.5,276.5L297.9,280.4Z" />
                      <text className="lg fill-white pointer-events-none" x="292.4951568988423" y="259.2291792317505" textAnchor="middle">125</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>126 · Level 1 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M294.9,228.1L302.1,224.5L309.6,221.1L317.4,217.9L325.4,214.9L333.8,212.0L342.4,209.4L369.8,242.5L362.7,244.7L355.8,247.1L349.2,249.5L342.7,252.2L336.6,255.0L330.6,258.0Z" />
                      <text className="lg fill-white pointer-events-none" x="333.278372493538" y="237.70518599523746" textAnchor="middle">126</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>127 · Level 1 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M345.4,208.5L354.5,206.2L363.8,204.0L373.5,202.0L383.5,200.2L393.9,198.6L404.7,197.2L421.3,232.5L412.3,233.6L403.7,235.0L395.5,236.4L387.5,238.1L379.8,239.9L372.3,241.8Z" />
                      <text className="lg fill-white pointer-events-none" x="384.4639543535239" y="223.21258241014277" textAnchor="middle">127</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>128 · Level 1 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M408.5,196.8L420.0,195.7L432.1,194.7L444.9,194.0L458.8,193.5L474.4,193.1L494.1,193.0L495.1,229.0L478.8,229.1L466.0,229.4L454.5,229.8L443.9,230.4L433.9,231.2L424.4,232.1Z" />
                      <text className="lg fill-white pointer-events-none" x="449.7272924175626" y="215.91481289053473" textAnchor="middle">128</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>201 · Level 2 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M506.9,157.0L538.1,157.3L562.2,158.1L583.6,159.3L603.3,161.0L621.7,163.2L639.1,165.8L621.9,194.8L606.7,192.4L590.5,190.5L573.3,189.0L554.5,187.9L533.4,187.3L506.0,187.0Z" />
                      <text className="lg fill-white pointer-events-none" x="578.4400337723317" y="178.162358665372" textAnchor="middle">201</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>202 · Level 2 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M643.2,166.6L659.5,169.8L675.0,173.5L689.7,177.6L703.8,182.3L717.2,187.3L729.9,192.9L701.5,218.4L690.4,213.6L678.6,209.1L666.3,205.1L653.4,201.5L639.8,198.2L625.5,195.4Z" />
                      <text className="lg fill-white pointer-events-none" x="678.0212585302627" y="195.36763511102686" textAnchor="middle">202</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>203 · Level 2 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M732.9,194.3L744.9,200.3L756.1,206.9L766.8,213.9L776.8,221.3L786.2,229.2L794.9,237.5L758.5,257.6L750.8,250.3L742.6,243.4L733.9,236.8L724.5,230.7L714.6,225.0L704.2,219.7Z" />
                      <text className="lg fill-white pointer-events-none" x="750.3233027886981" y="229.355835263699" textAnchor="middle">203</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>204 · Level 2 · 3 left · KSh 5,000</title>
                      <path d="M796.9,239.6L804.8,248.5L812.1,257.8L818.7,267.6L824.7,277.9L830.0,288.7L834.6,300.1L793.3,312.4L789.2,302.5L784.6,293.0L779.4,284.0L773.6,275.4L767.2,267.2L760.3,259.4Z" />
                      <text className="lg fill-white pointer-events-none" x="799.0397230075282" y="279.79912195563077" textAnchor="middle">204</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>205 · Level 2 · 5 left · KSh 5,000</title>
                      <path d="M835.6,303.0L839.4,315.1L842.5,327.9L845.0,341.7L846.8,356.6L847.9,373.4L848.3,395.2L805.3,395.8L804.9,376.7L804.0,362.0L802.4,348.9L800.3,336.8L797.5,325.6L794.2,314.9Z" />
                      <text className="lg fill-white pointer-events-none" x="823.7006192463001" y="349.27439504255926" textAnchor="middle">205</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>206 · Level 2 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M848.3,404.8L847.9,426.6L846.8,443.4L845.0,458.3L842.5,472.1L839.4,484.9L835.6,497.0L794.2,485.1L797.5,474.4L800.3,463.2L802.4,451.1L804.0,438.0L804.9,423.3L805.3,404.2Z" />
                      <text className="lg fill-white pointer-events-none" x="823.7006192463001" y="458.72560495744074" textAnchor="middle">206</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>207 · Level 2 · 4 left · KSh 5,000</title>
                      <path d="M834.6,499.9L830.0,511.3L824.7,522.1L818.7,532.4L812.1,542.2L804.8,551.5L796.9,560.4L760.3,540.6L767.2,532.8L773.6,524.6L779.4,516.0L784.6,507.0L789.2,497.5L793.3,487.6Z" />
                      <text className="lg fill-white pointer-events-none" x="799.0397230075282" y="528.2008780443692" textAnchor="middle">207</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>208 · Level 2 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M794.9,562.5L786.2,570.8L776.8,578.7L766.8,586.1L756.1,593.1L744.9,599.7L732.9,605.7L704.2,580.3L714.6,575.0L724.5,569.3L733.9,563.2L742.6,556.6L750.8,549.7L758.5,542.4Z" />
                      <text className="lg fill-white pointer-events-none" x="750.3233027886981" y="578.644164736301" textAnchor="middle">208</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>209 · Level 2 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M729.9,607.1L717.2,612.7L703.8,617.7L689.7,622.4L675.0,626.5L659.5,630.2L643.2,633.4L625.5,604.6L639.8,601.8L653.4,598.5L666.3,594.9L678.6,590.9L690.4,586.4L701.5,581.6Z" />
                      <text className="lg fill-white pointer-events-none" x="678.0212585302627" y="612.6323648889731" textAnchor="middle">209</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>210 · Level 2 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M639.1,634.2L621.7,636.8L603.3,639.0L583.6,640.7L562.2,641.9L538.1,642.7L506.9,643.0L506.0,613.0L533.4,612.7L554.5,612.1L573.3,611.0L590.5,609.5L606.7,607.6L621.9,605.2Z" />
                      <text className="lg fill-white pointer-events-none" x="578.4400337723317" y="629.837641334628" textAnchor="middle">210</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>211 · Level 2 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M493.1,643.0L461.9,642.7L437.8,641.9L416.4,640.7L396.7,639.0L378.3,636.8L360.9,634.2L378.1,605.2L393.3,607.6L409.5,609.5L426.7,611.0L445.5,612.1L466.6,612.7L494.0,613.0Z" />
                      <text className="lg fill-white pointer-events-none" x="421.55996622766816" y="629.837641334628" textAnchor="middle">211</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>212 · Level 2 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M356.8,633.4L340.5,630.2L325.0,626.5L310.3,622.4L296.2,617.7L282.8,612.7L270.1,607.1L298.5,581.6L309.6,586.4L321.4,590.9L333.7,594.9L346.6,598.5L360.2,601.8L374.5,604.6Z" />
                      <text className="lg fill-white pointer-events-none" x="321.97874146973743" y="612.6323648889731" textAnchor="middle">212</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>213 · Level 2 · 5 left · KSh 5,000</title>
                      <path d="M267.1,605.7L255.1,599.7L243.9,593.1L233.2,586.1L223.2,578.7L213.8,570.8L205.1,562.5L241.5,542.4L249.2,549.7L257.4,556.6L266.1,563.2L275.5,569.3L285.4,575.0L295.8,580.3Z" />
                      <text className="lg fill-white pointer-events-none" x="249.67669721130187" y="578.644164736301" textAnchor="middle">213</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>214 · Level 2 · 80 left · KSh 5,000</title>
                      <path d="M203.1,560.4L195.2,551.5L187.9,542.2L181.3,532.4L175.3,522.1L170.0,511.3L165.4,499.9L206.7,487.6L210.8,497.5L215.4,507.0L220.6,516.0L226.4,524.6L232.8,532.8L239.7,540.6Z" />
                      <text className="lg fill-white pointer-events-none" x="200.9602769924718" y="528.2008780443692" textAnchor="middle">214</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>215 · Level 2 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M164.4,497.0L160.6,484.9L157.5,472.1L155.0,458.3L153.2,443.4L152.1,426.6L151.7,404.8L194.7,404.2L195.1,423.3L196.0,438.0L197.6,451.1L199.7,463.2L202.5,474.4L205.8,485.1Z" />
                      <text className="lg fill-white pointer-events-none" x="176.2993807536999" y="458.7256049574408" textAnchor="middle">215</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>216 · Level 2 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M151.7,395.2L152.1,373.4L153.2,356.6L155.0,341.7L157.5,327.9L160.6,315.1L164.4,303.0L205.8,314.9L202.5,325.6L199.7,336.8L197.6,348.9L196.0,362.0L195.1,376.7L194.7,395.8Z" />
                      <text className="lg fill-white pointer-events-none" x="176.2993807536999" y="349.27439504255926" textAnchor="middle">216</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>217 · Level 2 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M165.4,300.1L170.0,288.7L175.3,277.9L181.3,267.6L187.9,257.8L195.2,248.5L203.1,239.6L239.7,259.4L232.8,267.2L226.4,275.4L220.6,284.0L215.4,293.0L210.8,302.5L206.7,312.4Z" />
                      <text className="lg fill-white pointer-events-none" x="200.96027699247173" y="279.7991219556309" textAnchor="middle">217</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>218 · Level 2 · 3 left · KSh 5,000</title>
                      <path d="M205.1,237.5L213.8,229.2L223.2,221.3L233.2,213.9L243.9,206.9L255.1,200.3L267.1,194.3L295.8,219.7L285.4,225.0L275.5,230.7L266.1,236.8L257.4,243.4L249.2,250.3L241.5,257.6Z" />
                      <text className="lg fill-white pointer-events-none" x="249.6766972113018" y="229.355835263699" textAnchor="middle">218</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>219 · Level 2 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M270.1,192.9L282.8,187.3L296.2,182.3L310.3,177.6L325.0,173.5L340.5,169.8L356.8,166.6L374.5,195.4L360.2,198.2L346.6,201.5L333.7,205.1L321.4,209.1L309.6,213.6L298.5,218.4Z" />
                      <text className="lg fill-white pointer-events-none" x="321.9787414697373" y="195.36763511102686" textAnchor="middle">219</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>220 · Level 2 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M360.9,165.8L378.3,163.2L396.7,161.0L416.4,159.3L437.8,158.1L461.9,157.3L493.1,157.0L494.0,187.0L466.6,187.3L445.5,187.9L426.7,189.0L409.5,190.5L393.3,192.4L378.1,194.8Z" />
                      <text className="lg fill-white pointer-events-none" x="421.55996622766816" y="178.16235866537204" textAnchor="middle">220</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>401 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M508.7,92.5L532.7,92.6L551.8,93.0L568.9,93.5L584.8,94.1L599.8,95.0L614.1,96.1L599.1,136.1L586.7,135.2L573.6,134.4L559.9,133.8L545.0,133.4L528.4,133.1L507.6,133.0Z" />
                      <text className="lg fill-white pointer-events-none" x="564.3927322843949" y="117.63994006510694" textAnchor="middle">401</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>402 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M620.1,96.6L633.6,97.9L646.6,99.4L659.2,101.1L671.3,102.9L683.2,105.0L694.7,107.2L669.0,145.8L659.0,143.8L648.8,142.0L638.2,140.4L627.3,139.0L616.0,137.7L604.3,136.5Z" />
                      <text className="lg fill-white pointer-events-none" x="648.6807587623509" y="124.7464317957656" textAnchor="middle">402</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>403 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M699.6,108.2L710.7,110.7L721.4,113.4L731.9,116.2L742.1,119.2L752.0,122.4L761.6,125.8L727.2,161.9L718.8,159.0L710.2,156.2L701.3,153.6L692.2,151.1L682.9,148.8L673.3,146.6Z" />
                      <text className="lg fill-white pointer-events-none" x="716.6026072240943" y="138.8928687822406" textAnchor="middle">403</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>404 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M765.8,127.3L775.1,131.0L784.1,134.8L792.9,138.8L801.4,142.9L809.7,147.2L817.7,151.8L775.8,184.5L768.9,180.5L761.7,176.8L754.3,173.2L746.7,169.7L738.8,166.4L730.8,163.2Z" />
                      <text className="lg fill-white pointer-events-none" x="773.5792470767713" y="159.96156821882167" textAnchor="middle">404</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>405 · Level 3 · 2 left · KSh 15,000</title>
                      <path d="M821.1,153.8L828.8,158.5L836.2,163.5L843.4,168.6L850.3,173.9L856.9,179.3L863.4,184.9L815.5,213.3L809.9,208.4L804.1,203.6L798.1,199.1L791.9,194.6L785.5,190.3L778.8,186.2Z" />
                      <text className="lg fill-white pointer-events-none" x="820.7430706944186" y="187.82179853120869" textAnchor="middle">405</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>406 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M866.1,187.5L872.1,193.3L878.0,199.4L883.5,205.6L888.8,212.0L893.9,218.6L898.7,225.4L846.2,248.4L842.0,242.5L837.6,236.8L833.0,231.2L828.2,225.8L823.1,220.6L817.9,215.5Z" />
                      <text className="lg fill-white pointer-events-none" x="858.2574960755544" y="222.41355915942344" textAnchor="middle">406</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>407 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M900.7,228.4L905.1,235.4L909.3,242.7L913.2,250.1L916.9,257.7L920.3,265.5L923.4,273.6L867.6,290.2L864.9,283.3L862.0,276.4L858.8,269.8L855.4,263.4L851.8,257.1L847.9,251.0Z" />
                      <text className="lg fill-white pointer-events-none" x="885.9936857630796" y="263.9524277818806" textAnchor="middle">407</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>408 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M924.7,277.2L927.5,285.6L930.0,294.3L932.2,303.2L934.2,312.5L935.9,322.1L937.4,332.1L879.8,341.1L878.5,332.4L877.0,324.0L875.3,316.0L873.3,308.2L871.2,300.7L868.8,293.4Z" />
                      <text className="lg fill-white pointer-events-none" x="903.7611691680547" y="313.5855941320638" textAnchor="middle">408</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>409 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M938.0,336.7L939.0,347.5L939.9,359.1L940.4,371.8L940.7,386.6L940.7,409.5L940.5,425.2L882.5,421.9L882.7,408.2L882.7,388.4L882.4,375.5L881.9,364.5L881.2,354.4L880.3,345.0Z" />
                      <text className="lg fill-white pointer-events-none" x="911.406055487713" y="377.62061442972106" textAnchor="middle">409</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>410 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M940.3,431.1L939.7,443.5L938.8,454.9L937.7,465.6L936.3,475.8L934.6,485.5L932.7,494.8L875.7,482.3L877.4,474.2L878.8,465.8L880.0,457.0L881.0,447.7L881.8,437.8L882.3,427.0Z" />
                      <text className="lg fill-white pointer-events-none" x="908.8556807832745" y="465.2890986775427" textAnchor="middle">410</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>411 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M931.8,498.8L929.5,507.7L926.9,516.3L924.1,524.6L921.0,532.7L917.6,540.6L914.0,548.3L859.5,528.7L862.6,522.1L865.5,515.2L868.2,508.2L870.7,500.9L872.9,493.5L874.9,485.8Z" />
                      <text className="lg fill-white pointer-events-none" x="896.134687706462" y="520.3961938038493" textAnchor="middle">411</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>412 · Level 3 · 1 left · KSh 15,000</title>
                      <path d="M912.4,551.6L908.4,558.9L904.2,566.1L899.7,573.1L894.9,579.9L889.9,586.6L884.7,593.0L834.0,567.6L838.6,562.0L842.9,556.2L847.0,550.3L850.9,544.2L854.6,538.0L858.1,531.6Z" />
                      <text className="lg fill-white pointer-events-none" x="873.3598432477013" y="565.7209124107824" textAnchor="middle">412</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>413 · Level 3 · 3 left · KSh 15,000</title>
                      <path d="M882.3,595.8L876.7,602.0L870.8,608.0L864.7,613.8L858.4,619.5L851.8,625.0L844.9,630.3L799.5,599.9L805.4,595.3L811.2,590.6L816.7,585.6L822.0,580.6L827.1,575.4L832.0,570.0Z" />
                      <text className="lg fill-white pointer-events-none" x="840.7113393914792" y="603.726855145379" textAnchor="middle">413</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>414 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M841.8,632.6L834.6,637.6L827.1,642.5L819.4,647.2L811.4,651.8L803.2,656.1L794.8,660.3L755.9,626.1L763.3,622.4L770.4,618.6L777.3,614.7L784.0,610.6L790.5,606.3L796.8,601.9Z" />
                      <text className="lg fill-white pointer-events-none" x="798.3663844926884" y="634.9503617911857" textAnchor="middle">414</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>415 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M791.0,662.1L782.1,666.1L773.1,669.8L763.7,673.4L754.1,676.9L744.3,680.1L734.1,683.1L703.3,645.9L712.1,643.2L720.7,640.4L729.0,637.4L737.1,634.3L745.0,631.0L752.6,627.6Z" />
                      <text className="lg fill-white pointer-events-none" x="746.351378971363" y="659.4295334696102" textAnchor="middle">415</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>416 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M729.6,684.4L719.1,687.2L708.3,689.9L697.1,692.3L685.7,694.6L674.0,696.6L661.9,698.5L640.5,659.2L651.1,657.6L661.3,655.8L671.2,653.8L680.8,651.7L690.2,649.4L699.4,647.0Z" />
                      <text className="lg fill-white pointer-events-none" x="684.1620069454314" y="677.0538816976361" textAnchor="middle">416</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>417 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M656.4,699.3L643.8,701.0L630.7,702.4L617.1,703.7L603.0,704.8L588.2,705.7L572.5,706.4L563.0,666.1L576.6,665.4L589.4,664.6L601.7,663.7L613.5,662.6L624.8,661.3L635.8,659.9Z" />
                      <text className="lg fill-white pointer-events-none" x="609.4084324413088" y="687.6924289327649" textAnchor="middle">417</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>418 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M565.3,706.7L547.8,707.1L528.1,707.4L500.0,707.5L471.9,707.4L452.2,707.1L434.7,706.7L443.3,666.3L458.5,666.7L475.6,666.9L500.0,667.0L524.4,666.9L541.5,666.7L556.7,666.3Z" />
                      <text className="lg fill-white pointer-events-none" x="500.00000000013904" y="691.25" textAnchor="middle">418</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>419 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M427.5,706.4L411.8,705.7L397.0,704.8L382.9,703.7L369.3,702.4L356.2,701.0L343.6,699.3L364.2,659.9L375.2,661.3L386.5,662.6L398.3,663.7L410.6,664.6L423.4,665.4L437.0,666.1Z" />
                      <text className="lg fill-white pointer-events-none" x="390.591567558691" y="687.6924289327649" textAnchor="middle">419</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>420 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M338.1,698.5L326.0,696.6L314.3,694.6L302.9,692.3L291.7,689.9L280.9,687.2L270.4,684.4L300.6,647.0L309.8,649.4L319.2,651.7L328.8,653.8L338.7,655.8L348.9,657.6L359.5,659.2Z" />
                      <text className="lg fill-white pointer-events-none" x="315.8379930545683" y="677.0538816976361" textAnchor="middle">420</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>421 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M265.9,683.1L255.7,680.1L245.9,676.9L236.3,673.4L226.9,669.8L217.9,666.1L209.0,662.1L247.4,627.6L255.0,631.0L262.9,634.3L271.0,637.4L279.3,640.4L287.9,643.2L296.7,645.9Z" />
                      <text className="lg fill-white pointer-events-none" x="253.64862102863682" y="659.4295334696102" textAnchor="middle">421</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>422 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M205.2,660.3L196.8,656.1L188.6,651.8L180.6,647.2L172.9,642.5L165.4,637.6L158.2,632.6L203.2,601.9L209.5,606.3L216.0,610.6L222.7,614.7L229.6,618.6L236.7,622.4L244.1,626.1Z" />
                      <text className="lg fill-white pointer-events-none" x="201.6336155073115" y="634.9503617911857" textAnchor="middle">422</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>423 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M155.1,630.3L148.2,625.0L141.6,619.5L135.3,613.8L129.2,608.0L123.3,602.0L117.7,595.8L168.0,570.0L172.9,575.4L178.0,580.6L183.3,585.6L188.8,590.6L194.6,595.3L200.5,599.9Z" />
                      <text className="lg fill-white pointer-events-none" x="159.2886606085208" y="603.726855145379" textAnchor="middle">423</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>424 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M115.3,593.0L110.1,586.6L105.1,579.9L100.3,573.1L95.8,566.1L91.6,558.9L87.6,551.6L141.9,531.6L145.4,538.0L149.1,544.2L153.0,550.3L157.1,556.2L161.4,562.0L166.0,567.6Z" />
                      <text className="lg fill-white pointer-events-none" x="126.64015675229871" y="565.7209124107824" textAnchor="middle">424</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>425 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M86.0,548.3L82.4,540.6L79.0,532.7L75.9,524.6L73.1,516.3L70.5,507.7L68.2,498.8L125.1,485.8L127.1,493.5L129.3,500.9L131.8,508.2L134.5,515.2L137.4,522.1L140.5,528.7Z" />
                      <text className="lg fill-white pointer-events-none" x="103.86531229353795" y="520.3961938038491" textAnchor="middle">425</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>426 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M67.3,494.8L65.4,485.5L63.7,475.8L62.3,465.6L61.2,454.9L60.3,443.5L59.7,431.1L117.7,427.0L118.2,437.8L119.0,447.7L120.0,457.0L121.2,465.8L122.6,474.2L124.3,482.3Z" />
                      <text className="lg fill-white pointer-events-none" x="91.14431921672548" y="465.2890986775428" textAnchor="middle">426</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>427 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M59.5,425.2L59.3,409.5L59.3,386.6L59.6,371.8L60.1,359.1L61.0,347.5L62.0,336.7L119.7,345.0L118.8,354.4L118.1,364.5L117.6,375.5L117.3,388.4L117.3,408.2L117.5,421.9Z" />
                      <text className="lg fill-white pointer-events-none" x="88.59394451228695" y="377.6206144297207" textAnchor="middle">427</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>428 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M62.6,332.1L64.1,322.1L65.8,312.5L67.8,303.2L70.0,294.3L72.5,285.6L75.3,277.2L131.2,293.4L128.8,300.7L126.7,308.2L124.7,316.0L123.0,324.0L121.5,332.4L120.2,341.1Z" />
                      <text className="lg fill-white pointer-events-none" x="96.23883083194528" y="313.58559413206353" textAnchor="middle">428</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>429 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M76.6,273.6L79.7,265.5L83.1,257.7L86.8,250.1L90.7,242.7L94.9,235.4L99.3,228.4L152.1,251.0L148.2,257.1L144.6,263.4L141.2,269.8L138.0,276.4L135.1,283.3L132.4,290.2Z" />
                      <text className="lg fill-white pointer-events-none" x="114.00631423692039" y="263.9524277818805" textAnchor="middle">429</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>430 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M101.3,225.4L106.1,218.6L111.2,212.0L116.5,205.6L122.0,199.4L127.9,193.3L133.9,187.5L182.1,215.5L176.9,220.6L171.8,225.8L167.0,231.2L162.4,236.8L158.0,242.5L153.8,248.4Z" />
                      <text className="lg fill-white pointer-events-none" x="141.7425039244457" y="222.41355915942336" textAnchor="middle">430</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>431 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M136.6,184.9L143.1,179.3L149.7,173.9L156.6,168.6L163.8,163.5L171.2,158.5L178.9,153.8L221.2,186.2L214.5,190.3L208.1,194.6L201.9,199.1L195.9,203.6L190.1,208.4L184.5,213.3Z" />
                      <text className="lg fill-white pointer-events-none" x="179.2569293055813" y="187.82179853120874" textAnchor="middle">431</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>432 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M182.3,151.8L190.3,147.2L198.6,142.9L207.1,138.8L215.9,134.8L224.9,131.0L234.2,127.3L269.2,163.2L261.2,166.4L253.3,169.7L245.7,173.2L238.3,176.8L231.1,180.5L224.2,184.5Z" />
                      <text className="lg fill-white pointer-events-none" x="226.4207529232287" y="159.9615682188217" textAnchor="middle">432</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>433 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M238.4,125.8L248.0,122.4L257.9,119.2L268.1,116.2L278.6,113.4L289.3,110.7L300.4,108.2L326.7,146.6L317.1,148.8L307.8,151.1L298.7,153.6L289.8,156.2L281.2,159.0L272.8,161.9Z" />
                      <text className="lg fill-white pointer-events-none" x="283.3973927759059" y="138.8928687822405" textAnchor="middle">433</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>434 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M305.3,107.2L316.8,105.0L328.7,102.9L340.8,101.1L353.4,99.4L366.4,97.9L379.9,96.6L395.7,136.5L384.0,137.7L372.7,139.0L361.8,140.4L351.2,142.0L341.0,143.8L331.0,145.8Z" />
                      <text className="lg fill-white pointer-events-none" x="351.3192412376494" y="124.7464317957656" textAnchor="middle">434</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>435 · Level 3 · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M385.9,96.1L400.2,95.0L415.2,94.1L431.1,93.5L448.2,93.0L467.3,92.6L491.3,92.5L492.4,133.0L471.6,133.1L455.0,133.4L440.1,133.8L426.4,134.4L413.3,135.2L400.9,136.1Z" />
                      <text className="lg fill-white pointer-events-none" x="435.6072677156054" y="117.63994006510694" textAnchor="middle">435</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>Gold F1 · Gold · 5 left · KSh 20,000</title>
                      <path d="M658.1,256.4L668.4,261.5L678.0,267.0L686.9,273.1L695.2,279.6L702.8,286.5L709.7,294.0L687.2,305.3L681.0,298.7L674.3,292.5L666.9,286.7L658.9,281.3L650.3,276.3L641.1,271.8Z" />
                      <text className="sm fill-white pointer-events-none" x="676.8860668181985" y="283.86135784491864" textAnchor="middle">1</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>Gold F2 · Gold · 1 left · KSh 20,000</title>
                      <path d="M711.0,295.5L717.1,303.5L722.5,312.0L727.2,321.1L731.2,330.7L734.5,340.9L737.2,351.9L711.8,357.0L709.4,347.2L706.4,338.1L702.9,329.5L698.6,321.4L693.8,313.8L688.4,306.7Z" />
                      <text className="sm fill-white pointer-events-none" x="715.0241773395244" y="329.2900898018089" textAnchor="middle">2</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>Gold F3 · Gold · 2 left · KSh 20,000</title>
                      <path d="M737.6,354.2L739.4,366.4L740.4,380.2L740.8,400.0L740.4,419.8L739.4,433.6L737.6,445.8L712.1,440.9L713.7,430.0L714.7,417.6L715.0,400.0L714.7,382.4L713.7,370.0L712.1,359.1Z" />
                      <text className="sm fill-white pointer-events-none" x="727.9" y="404" textAnchor="middle">3</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>Gold F4 · Gold · 1 left · KSh 20,000</title>
                      <path d="M737.2,448.1L734.5,459.1L731.2,469.3L727.2,478.9L722.5,488.0L717.1,496.5L711.0,504.5L688.4,493.3L693.8,486.2L698.6,478.6L702.9,470.5L706.4,461.9L709.4,452.8L711.8,443.0Z" />
                      <text className="sm fill-white pointer-events-none" x="715.0241773395244" y="478.7099101981911" textAnchor="middle">4</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Gold F5 · Gold · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M709.7,506.0L702.8,513.5L695.2,520.4L686.9,526.9L678.0,533.0L668.4,538.5L658.1,543.6L641.1,528.2L650.3,523.7L658.9,518.7L666.9,513.3L674.3,507.5L681.0,501.3L687.2,494.7Z" />
                      <text className="sm fill-white pointer-events-none" x="676.8860668181985" y="524.1386421550814" textAnchor="middle">5</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>Platinum1 · Platinum · 3 left · KSh 45,000</title>
                      <path d="M341.9,543.6L325.0,534.8L309.9,524.5L296.8,513.0L285.6,500.1L276.3,485.8L269.0,470.0L293.8,462.5L300.3,476.6L308.5,489.4L318.5,500.9L330.3,511.2L343.7,520.3L358.9,528.2Z" />
                      <text className="sm fill-white pointer-events-none" x="307.65379914369885" y="510.9444916882801" textAnchor="middle">1</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Platinum2 · Platinum · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M268.3,468.0L263.3,450.2L260.2,429.6L259.2,400.0L260.2,370.4L263.3,349.8L268.3,332.0L293.1,339.3L288.6,355.2L285.9,373.6L285.0,400.0L285.9,426.4L288.6,444.8L293.1,460.7Z" />
                      <text className="sm fill-white pointer-events-none" x="272.1" y="404.0000000000915" textAnchor="middle">2</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>Platinum3 · Platinum · 2 left · KSh 45,000</title>
                      <path d="M269.0,330.0L276.3,314.2L285.6,299.9L296.8,287.0L309.9,275.5L325.0,265.2L341.9,256.4L358.9,271.8L343.7,279.7L330.3,288.8L318.5,299.1L308.5,310.6L300.3,323.4L293.8,337.5Z" />
                      <text className="sm fill-white pointer-events-none" x="307.65379914369873" y="297.05550831172" textAnchor="middle">3</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box301 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M507.4,139.0L521.9,139.1L533.8,139.2L544.5,139.4L554.5,139.7L563.9,140.0L572.9,140.4L569.1,153.9L560.6,153.5L551.6,153.1L542.2,152.9L532.0,152.7L520.8,152.6L507.0,152.5Z" />
                      <text className="sm fill-white pointer-events-none" x="543.342234564467" y="150.1360143233253" textAnchor="middle">301</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box302 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M578.5,140.7L587.0,141.3L595.2,141.9L603.2,142.6L610.9,143.3L618.5,144.1L625.9,145.0L619.4,158.2L612.4,157.4L605.2,156.6L597.8,155.9L590.3,155.2L582.5,154.7L574.5,154.2Z" />
                      <text className="sm fill-white pointer-events-none" x="600.5001802066638" y="153.22133703366808" textAnchor="middle">302</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box303 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M630.6,145.6L637.7,146.7L644.7,147.7L651.6,148.9L658.3,150.1L664.9,151.4L671.4,152.8L662.5,165.5L656.4,164.3L650.1,163.0L643.7,161.9L637.2,160.8L630.6,159.8L623.8,158.8Z" />
                      <text className="sm fill-white pointer-events-none" x="647.6681738101576" y="159.37738939979855" textAnchor="middle">303</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>Box304 · Skyboxes · 3 left · KSh 50,000</title>
                      <path d="M675.5,153.7L681.8,155.2L687.9,156.7L694.0,158.3L699.9,160.0L705.8,161.8L711.5,163.6L700.5,175.8L695.1,174.1L689.6,172.4L683.9,170.8L678.2,169.3L672.4,167.8L666.4,166.4Z" />
                      <text className="sm fill-white pointer-events-none" x="688.958092905583" y="168.57647035125717" textAnchor="middle">304</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>Box305 · Skyboxes · 2 left · KSh 50,000</title>
                      <path d="M715.1,164.8L720.7,166.8L726.1,168.8L731.5,170.9L736.8,173.0L741.9,175.2L747.0,177.5L734.2,189.0L729.4,186.8L724.5,184.7L719.5,182.7L714.4,180.7L709.3,178.8L704.0,177.0Z" />
                      <text className="sm fill-white pointer-events-none" x="725.5097971805526" y="180.7810403764008" textAnchor="middle">305</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>Box306 · Skyboxes · 1 left · KSh 50,000</title>
                      <path d="M750.2,179.0L755.1,181.4L759.9,183.9L764.6,186.4L769.2,189.0L773.7,191.7L778.1,194.4L763.7,205.1L759.5,202.5L755.3,199.9L750.9,197.5L746.4,195.1L741.9,192.7L737.2,190.5Z" />
                      <text className="sm fill-white pointer-events-none" x="757.7320768977409" y="195.9495131256962" textAnchor="middle">306</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box307 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M780.9,196.2L785.1,199.1L789.3,202.0L793.3,205.0L797.3,208.1L801.2,211.2L804.9,214.4L789.2,224.0L785.6,220.9L781.9,218.0L778.2,215.1L774.3,212.3L770.4,209.5L766.4,206.8Z" />
                      <text className="sm fill-white pointer-events-none" x="785.7587755576847" y="214.04613034692122" textAnchor="middle">307</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box308 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M807.3,216.5L810.9,219.8L814.4,223.1L817.8,226.6L821.1,230.1L824.3,233.7L827.5,237.3L810.5,245.7L807.6,242.3L804.5,238.9L801.4,235.5L798.2,232.3L794.8,229.1L791.4,226.0Z" />
                      <text className="sm fill-white pointer-events-none" x="809.6038485704296" y="235.0582948102032" textAnchor="middle">308</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box309 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M829.4,239.7L832.4,243.4L835.2,247.3L838.0,251.2L840.6,255.2L843.2,259.2L845.6,263.3L827.8,270.4L825.4,266.5L823.0,262.6L820.5,258.9L817.9,255.2L815.2,251.5L812.4,248.0Z" />
                      <text className="sm fill-white pointer-events-none" x="829.2285485160262" y="259.0293054289742" textAnchor="middle">309</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>Box310 · Skyboxes · 3 left · KSh 50,000</title>
                      <path d="M847.2,266.0L849.4,270.3L851.6,274.6L853.7,279.0L855.7,283.5L857.6,288.1L859.4,292.7L840.8,298.3L839.1,293.8L837.3,289.5L835.4,285.3L833.4,281.1L831.4,277.0L829.2,273.0Z" />
                      <text className="sm fill-white pointer-events-none" x="844.5751681839962" y="286.1279611213082" textAnchor="middle">310</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>Box311 · Skyboxes · 1 left · KSh 50,000</title>
                      <path d="M860.5,295.8L862.1,300.6L863.6,305.5L865.0,310.5L866.3,315.6L867.5,320.9L868.7,326.3L849.6,330.1L848.5,325.0L847.4,320.0L846.1,315.1L844.8,310.4L843.4,305.7L841.8,301.2Z" />
                      <text className="sm fill-white pointer-events-none" x="855.5856698822046" y="316.826878715645" textAnchor="middle">311</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>Box312 · Skyboxes · 4 left · KSh 50,000</title>
                      <path d="M869.3,329.8L870.3,335.4L871.1,341.2L871.8,347.2L872.5,353.4L873.0,359.8L873.4,366.7L854.1,368.4L853.7,361.9L853.2,355.8L852.6,349.9L851.9,344.2L851.1,338.8L850.2,333.4Z" />
                      <text className="sm fill-white pointer-events-none" x="862.2125207759868" y="352.540475955003" textAnchor="middle">312</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box313 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M873.6,371.3L873.9,379.0L874.0,387.7L874.1,400.0L874.0,412.3L873.9,421.0L873.6,428.7L854.3,427.2L854.6,419.9L854.7,411.7L854.8,400.0L854.7,388.3L854.6,380.1L854.3,372.8Z" />
                      <text className="sm fill-white pointer-events-none" x="864.425" y="404" textAnchor="middle">313</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box314 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M873.4,433.3L873.0,440.2L872.5,446.6L871.8,452.8L871.1,458.8L870.3,464.6L869.3,470.2L850.2,466.6L851.1,461.2L851.9,455.8L852.6,450.1L853.2,444.2L853.7,438.1L854.1,431.6Z" />
                      <text className="sm fill-white pointer-events-none" x="862.2125207759868" y="455.459524044997" textAnchor="middle">314</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box315 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M868.7,473.7L867.5,479.1L866.3,484.4L865.0,489.5L863.6,494.5L862.1,499.4L860.5,504.2L841.8,498.8L843.4,494.3L844.8,489.6L846.1,484.9L847.4,480.0L848.5,475.0L849.6,469.9Z" />
                      <text className="sm fill-white pointer-events-none" x="855.5856698822045" y="491.17312128435503" textAnchor="middle">315</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box316 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M859.4,507.3L857.6,511.9L855.7,516.5L853.7,521.0L851.6,525.4L849.4,529.7L847.2,534.0L829.2,527.0L831.4,523.0L833.4,518.9L835.4,514.7L837.3,510.5L839.1,506.2L840.8,501.7Z" />
                      <text className="sm fill-white pointer-events-none" x="844.5751681839962" y="521.8720388786919" textAnchor="middle">316</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box317 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M845.6,536.7L843.2,540.8L840.6,544.8L838.0,548.8L835.2,552.7L832.4,556.6L829.4,560.3L812.4,552.0L815.2,548.5L817.9,544.8L820.5,541.1L823.0,537.4L825.4,533.5L827.8,529.6Z" />
                      <text className="sm fill-white pointer-events-none" x="829.2285485160262" y="548.9706945710258" textAnchor="middle">317</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box318 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M827.5,562.7L824.3,566.3L821.1,569.9L817.8,573.4L814.4,576.9L810.9,580.2L807.3,583.5L791.4,574.0L794.8,570.9L798.2,567.7L801.4,564.5L804.5,561.1L807.6,557.7L810.5,554.3Z" />
                      <text className="sm fill-white pointer-events-none" x="809.6038485704296" y="572.9417051897968" textAnchor="middle">318</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box319 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M804.9,585.6L801.2,588.8L797.3,591.9L793.3,595.0L789.3,598.0L785.1,600.9L780.9,603.8L766.4,593.2L770.4,590.5L774.3,587.7L778.2,584.9L781.9,582.0L785.6,579.1L789.2,576.0Z" />
                      <text className="sm fill-white pointer-events-none" x="785.7587755576847" y="593.9538696530789" textAnchor="middle">319</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box320 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M778.1,605.6L773.7,608.3L769.2,611.0L764.6,613.6L759.9,616.1L755.1,618.6L750.2,621.0L737.2,609.5L741.9,607.3L746.4,604.9L750.9,602.5L755.3,600.1L759.5,597.5L763.7,594.9Z" />
                      <text className="sm fill-white pointer-events-none" x="757.7320768977409" y="612.0504868743038" textAnchor="middle">320</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box321 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M747.0,622.5L741.9,624.8L736.8,627.0L731.5,629.1L726.1,631.2L720.7,633.2L715.1,635.2L704.0,623.0L709.3,621.2L714.4,619.3L719.5,617.3L724.5,615.3L729.4,613.2L734.2,611.0Z" />
                      <text className="sm fill-white pointer-events-none" x="725.5097971805526" y="627.2189596235992" textAnchor="middle">321</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box322 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M711.5,636.4L705.8,638.2L699.9,640.0L694.0,641.7L687.9,643.3L681.8,644.8L675.5,646.3L666.4,633.6L672.4,632.2L678.2,630.7L683.9,629.2L689.6,627.6L695.1,625.9L700.5,624.2Z" />
                      <text className="sm fill-white pointer-events-none" x="688.9580929055829" y="639.4235296487428" textAnchor="middle">322</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box323 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M671.4,647.2L664.9,648.6L658.3,649.9L651.6,651.1L644.7,652.3L637.7,653.3L630.6,654.4L623.8,641.2L630.6,640.2L637.2,639.2L643.7,638.1L650.1,637.0L656.4,635.7L662.5,634.5Z" />
                      <text className="sm fill-white pointer-events-none" x="647.6681738101576" y="648.6226106002015" textAnchor="middle">323</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box324 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M625.9,655.0L618.5,655.9L610.9,656.7L603.2,657.4L595.2,658.1L587.0,658.7L578.5,659.3L574.5,645.8L582.5,645.3L590.3,644.8L597.8,644.1L605.2,643.4L612.4,642.6L619.4,641.8Z" />
                      <text className="sm fill-white pointer-events-none" x="600.5001802066638" y="654.7786629663319" textAnchor="middle">324</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box325 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M572.9,659.6L563.9,660.0L554.5,660.3L544.5,660.6L533.8,660.8L521.9,660.9L507.4,661.0L507.0,647.5L520.8,647.4L532.0,647.3L542.2,647.1L551.6,646.9L560.6,646.5L569.1,646.1Z" />
                      <text className="sm fill-white pointer-events-none" x="543.342234564467" y="657.8639856766747" textAnchor="middle">325</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box326 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M492.6,661.0L478.1,660.9L466.2,660.8L455.5,660.6L445.5,660.3L436.1,660.0L427.1,659.6L430.9,646.1L439.4,646.5L448.4,646.9L457.8,647.1L468.0,647.3L479.2,647.4L493.0,647.5Z" />
                      <text className="sm fill-white pointer-events-none" x="456.6577654355332" y="657.8639856766747" textAnchor="middle">326</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box327 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M421.5,659.3L413.0,658.7L404.8,658.1L396.8,657.4L389.1,656.7L381.5,655.9L374.1,655.0L380.6,641.8L387.6,642.6L394.8,643.4L402.2,644.1L409.7,644.8L417.5,645.3L425.5,645.8Z" />
                      <text className="sm fill-white pointer-events-none" x="399.49981979333603" y="654.7786629663319" textAnchor="middle">327</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box328 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M369.4,654.4L362.3,653.3L355.3,652.3L348.4,651.1L341.7,649.9L335.1,648.6L328.6,647.2L337.5,634.5L343.6,635.7L349.9,637.0L356.3,638.1L362.8,639.2L369.4,640.2L376.2,641.2Z" />
                      <text className="sm fill-white pointer-events-none" x="352.3318261898425" y="648.6226106002015" textAnchor="middle">328</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box329 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M324.5,646.3L318.2,644.8L312.1,643.3L306.0,641.7L300.1,640.0L294.2,638.2L288.5,636.4L299.5,624.2L304.9,625.9L310.4,627.6L316.1,629.2L321.8,630.7L327.6,632.2L333.6,633.6Z" />
                      <text className="sm fill-white pointer-events-none" x="311.041907094417" y="639.4235296487428" textAnchor="middle">329</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>Box330 · Skyboxes · 3 left · KSh 50,000</title>
                      <path d="M284.9,635.2L279.3,633.2L273.9,631.2L268.5,629.1L263.2,627.0L258.1,624.8L253.0,622.5L265.8,611.0L270.6,613.2L275.5,615.3L280.5,617.3L285.6,619.3L290.7,621.2L296.0,623.0Z" />
                      <text className="sm fill-white pointer-events-none" x="274.4902028194475" y="627.2189596235992" textAnchor="middle">330</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>Box331 · Skyboxes · 8 left · KSh 50,000</title>
                      <path d="M249.8,621.0L244.9,618.6L240.1,616.1L235.4,613.6L230.8,611.0L226.3,608.3L221.9,605.6L236.3,594.9L240.5,597.5L244.7,600.1L249.1,602.5L253.6,604.9L258.1,607.3L262.8,609.5Z" />
                      <text className="sm fill-white pointer-events-none" x="242.2679231022592" y="612.0504868743039" textAnchor="middle">331</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box332 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M219.1,603.8L214.9,600.9L210.7,598.0L206.7,595.0L202.7,591.9L198.8,588.8L195.1,585.6L210.8,576.0L214.4,579.1L218.1,582.0L221.8,584.9L225.7,587.7L229.6,590.5L233.6,593.2Z" />
                      <text className="sm fill-white pointer-events-none" x="214.24122444231523" y="593.9538696530788" textAnchor="middle">332</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box333 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M192.7,583.5L189.1,580.2L185.6,576.9L182.2,573.4L178.9,569.9L175.7,566.3L172.5,562.7L189.5,554.3L192.4,557.7L195.5,561.1L198.6,564.5L201.8,567.7L205.2,570.9L208.6,574.0Z" />
                      <text className="sm fill-white pointer-events-none" x="190.39615142957047" y="572.9417051897968" textAnchor="middle">333</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box334 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M170.6,560.3L167.6,556.6L164.8,552.7L162.0,548.8L159.4,544.8L156.8,540.8L154.4,536.7L172.2,529.6L174.6,533.5L177.0,537.4L179.5,541.1L182.1,544.8L184.8,548.5L187.6,552.0Z" />
                      <text className="sm fill-white pointer-events-none" x="170.77145148397375" y="548.9706945710258" textAnchor="middle">334</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box335 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M152.8,534.0L150.6,529.7L148.4,525.4L146.3,521.0L144.3,516.5L142.4,511.9L140.6,507.3L159.2,501.7L160.9,506.2L162.7,510.5L164.6,514.7L166.6,518.9L168.6,523.0L170.8,527.0Z" />
                      <text className="sm fill-white pointer-events-none" x="155.4248318160038" y="521.8720388786918" textAnchor="middle">335</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box336 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M139.5,504.2L137.9,499.4L136.4,494.5L135.0,489.5L133.7,484.4L132.5,479.1L131.3,473.7L150.4,469.9L151.5,475.0L152.6,480.0L153.9,484.9L155.2,489.6L156.6,494.3L158.2,498.8Z" />
                      <text className="sm fill-white pointer-events-none" x="144.4143301177955" y="491.17312128435503" textAnchor="middle">336</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box337 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M130.7,470.2L129.7,464.6L128.9,458.8L128.2,452.8L127.5,446.6L127.0,440.2L126.6,433.3L145.9,431.6L146.3,438.1L146.8,444.2L147.4,450.1L148.1,455.8L148.9,461.2L149.8,466.6Z" />
                      <text className="sm fill-white pointer-events-none" x="137.78747922401317" y="455.45952404499707" textAnchor="middle">337</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box338 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M126.4,428.7L126.1,421.0L126.0,412.3L125.9,400.0L126.0,387.7L126.1,379.0L126.4,371.3L145.7,372.8L145.4,380.1L145.3,388.3L145.3,400.0L145.3,411.7L145.4,419.9L145.7,427.2Z" />
                      <text className="sm fill-white pointer-events-none" x="135.57500000000005" y="404.0000000001463" textAnchor="middle">338</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box339 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M126.6,366.7L127.0,359.8L127.5,353.4L128.2,347.2L128.9,341.2L129.7,335.4L130.7,329.8L149.8,333.4L148.9,338.8L148.1,344.2L147.4,349.9L146.8,355.8L146.3,361.9L145.9,368.4Z" />
                      <text className="sm fill-white pointer-events-none" x="137.7874792240131" y="352.54047595500316" textAnchor="middle">339</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box340 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M131.3,326.3L132.5,320.9L133.7,315.6L135.0,310.5L136.4,305.5L137.9,300.6L139.5,295.8L158.2,301.2L156.6,305.7L155.2,310.4L153.9,315.1L152.6,320.0L151.5,325.0L150.4,330.1Z" />
                      <text className="sm fill-white pointer-events-none" x="144.41433011779554" y="316.8268787156448" textAnchor="middle">340</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box341 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M140.6,292.7L142.4,288.1L144.3,283.5L146.3,279.0L148.4,274.6L150.6,270.3L152.8,266.0L170.8,273.0L168.6,277.0L166.6,281.1L164.6,285.3L162.7,289.5L160.9,293.8L159.2,298.3Z" />
                      <text className="sm fill-white pointer-events-none" x="155.42483181600386" y="286.1279611213081" textAnchor="middle">341</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box342 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M154.4,263.3L156.8,259.2L159.4,255.2L162.0,251.2L164.8,247.3L167.6,243.4L170.6,239.7L187.6,248.0L184.8,251.5L182.1,255.2L179.5,258.9L177.0,262.6L174.6,266.5L172.2,270.4Z" />
                      <text className="sm fill-white pointer-events-none" x="170.77145148397375" y="259.0293054289742" textAnchor="middle">342</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box343 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M172.5,237.3L175.7,233.7L178.9,230.1L182.2,226.6L185.6,223.1L189.1,219.8L192.7,216.5L208.6,226.0L205.2,229.1L201.8,232.3L198.6,235.5L195.5,238.9L192.4,242.3L189.5,245.7Z" />
                      <text className="sm fill-white pointer-events-none" x="190.39615142957035" y="235.05829481020322" textAnchor="middle">343</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box344 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M195.1,214.4L198.8,211.2L202.7,208.1L206.7,205.0L210.7,202.0L214.9,199.1L219.1,196.2L233.6,206.8L229.6,209.5L225.7,212.3L221.8,215.1L218.1,218.0L214.4,220.9L210.8,224.0Z" />
                      <text className="sm fill-white pointer-events-none" x="214.24122444231517" y="214.04613034692125" textAnchor="middle">344</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box345 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M221.9,194.4L226.3,191.7L230.8,189.0L235.4,186.4L240.1,183.9L244.9,181.4L249.8,179.0L262.8,190.5L258.1,192.7L253.6,195.1L249.1,197.5L244.7,199.9L240.5,202.5L236.3,205.1Z" />
                      <text className="sm fill-white pointer-events-none" x="242.26792310225915" y="195.94951312569614" textAnchor="middle">345</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box346 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M253.0,177.5L258.1,175.2L263.2,173.0L268.5,170.9L273.9,168.8L279.3,166.8L284.9,164.8L296.0,177.0L290.7,178.8L285.6,180.7L280.5,182.7L275.5,184.7L270.6,186.8L265.8,189.0Z" />
                      <text className="sm fill-white pointer-events-none" x="274.4902028194475" y="180.78104037640074" textAnchor="middle">346</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box347 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M288.5,163.6L294.2,161.8L300.1,160.0L306.0,158.3L312.1,156.7L318.2,155.2L324.5,153.7L333.6,166.4L327.6,167.8L321.8,169.3L316.1,170.8L310.4,172.4L304.9,174.1L299.5,175.8Z" />
                      <text className="sm fill-white pointer-events-none" x="311.04190709441696" y="168.5764703512572" textAnchor="middle">347</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>Box348 · Skyboxes · 5 left · KSh 50,000</title>
                      <path d="M328.6,152.8L335.1,151.4L341.7,150.1L348.4,148.9L355.3,147.7L362.3,146.7L369.4,145.6L376.2,158.8L369.4,159.8L362.8,160.8L356.3,161.9L349.9,163.0L343.6,164.3L337.5,165.5Z" />
                      <text className="sm fill-white pointer-events-none" x="352.33182618984245" y="159.37738939979855" textAnchor="middle">348</text>
                    </g>
                    <g className="sec sold" tabIndex={-1}>
                      <title>Box349 · Skyboxes · sold out</title>
                      <path style={{ fill: "url(\"#hatchbks-1\")" } as CSSProperties} d="M374.1,145.0L381.5,144.1L389.1,143.3L396.8,142.6L404.8,141.9L413.0,141.3L421.5,140.7L425.5,154.2L417.5,154.7L409.7,155.2L402.2,155.9L394.8,156.6L387.6,157.4L380.6,158.2Z" />
                      <text className="sm fill-white pointer-events-none" x="399.49981979333575" y="153.22133703366814" textAnchor="middle">349</text>
                    </g>
                    <g className="sec available" tabIndex={0}>
                      <title>Box350 · Skyboxes · 3 left · KSh 50,000</title>
                      <path d="M427.1,140.4L436.1,140.0L445.5,139.7L455.5,139.4L466.2,139.2L478.1,139.1L492.6,139.0L493.0,152.5L479.2,152.6L468.0,152.7L457.8,152.9L448.4,153.1L439.4,153.5L430.9,153.9Z" />
                      <text className="sm fill-white pointer-events-none" x="456.6577654355331" y="150.1360143233253" textAnchor="middle">350</text>
                    </g>
                  </g>
                </svg>
                <div className="bks-tools flex flex-col gap-[8px] left-[14px] absolute top-[14px]">
                  <button>+</button>
                  <button>−</button>
                  <button>⟲</button>
                </div>
                <div className="bks-tabs flex gap-[8px] absolute right-[14px] top-[14px]">
                  <button>LEVEL 1</button>
                  <button>LEVEL 2</button>
                  <button>LEVEL 3</button>
                </div>
                <ul className="bks-legend list-none absolute right-[14px] [@media(max-width:1100px)]:bottom-[70px]">
                  <li><i className="available h-[14px] w-[14px]" />Available</li>
                  <li><i className="selected h-[14px] w-[14px]" />Selected</li>
                  <li><i className="taken h-[14px] w-[14px]" />Taken</li>
                  <li><i className="sold h-[14px] w-[14px]" />Sold out</li>
                </ul>
                <div className="bks-hint bottom-[14px] absolute right-[14px]">Scroll to zoom · drag to pan · tap a section</div>
              </div>
              <ImportedAside />
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

function ImportedAside() {
  return (
    <aside className="bks-panel flex flex-col gap-4">
      <div className="bks-qty items-center flex justify-between">
        <h3>Tickets</h3>
        <div>
          <button>−</button>
          <b>2</b>
          <button>+</button>
        </div>
      </div>
      <div className="bks-phases flex gap-[0.7rem] overflow-x-auto" />
      <button className={"bks-cta [&:hover]:[filter:brightness(1.1)]"}>Find my seats</button>
      <div className="bks-sechead items-center flex justify-between">
        <div>
          <h3>Or choose a section</h3>
          <small>29 sections available</small>
        </div>
        <div className="bks-seg flex">
          <button className="on" data-s="cheapest">Cheapest</button>
          <button data-s="section">Section</button>
        </div>
      </div>
      <div className="bks-list flex-1 min-h-[240px] overflow-auto">
        <div className="bks-tier">
          <button className="bks-th items-center flex gap-4 justify-between text-left w-full">
            <span>
              <b>Level 1</b>
              <small>Sections 101–128 · 28 sections</small>
              <em>8 seats left</em>
            </span>
            <span className="pr text-right">
              <small>From</small>
              <b>KSh 2,500</b>
            </span>
            <i>⌄</i>
          </button>
          <div className="bks-pick hidden flex-wrap gap-[0.4rem] max-h-[160px] overflow-auto">
            <button>101</button>
            <button>102</button>
            <button disabled>103</button>
            <button>104</button>
            <button disabled>105</button>
            <button disabled>106</button>
            <button>107</button>
            <button disabled>108</button>
            <button disabled>109</button>
            <button disabled>110</button>
            <button disabled>111</button>
            <button disabled>112</button>
            <button disabled>113</button>
            <button disabled>114</button>
            <button disabled>115</button>
            <button disabled>116</button>
            <button disabled>117</button>
            <button disabled>118</button>
            <button disabled>119</button>
            <button disabled>120</button>
            <button disabled>121</button>
            <button disabled>122</button>
            <button disabled>123</button>
            <button disabled>124</button>
            <button disabled>125</button>
            <button disabled>126</button>
            <button disabled>127</button>
            <button disabled>128</button>
          </div>
        </div>
        <div className="bks-tier">
          <button className="bks-th items-center flex gap-4 justify-between text-left w-full">
            <span>
              <b>Level 2</b>
              <small>Sections 201–220 · 20 sections</small>
              <em>100 seats left</em>
            </span>
            <span className="pr text-right">
              <small>From</small>
              <b>KSh 5,000</b>
            </span>
            <i>⌄</i>
          </button>
          <div className="bks-pick hidden flex-wrap gap-[0.4rem] max-h-[160px] overflow-auto">
            <button disabled>201</button>
            <button disabled>202</button>
            <button disabled>203</button>
            <button>204</button>
            <button>205</button>
            <button disabled>206</button>
            <button>207</button>
            <button disabled>208</button>
            <button disabled>209</button>
            <button disabled>210</button>
            <button disabled>211</button>
            <button disabled>212</button>
            <button>213</button>
            <button>214</button>
            <button disabled>215</button>
            <button disabled>216</button>
            <button disabled>217</button>
            <button>218</button>
            <button disabled>219</button>
            <button disabled>220</button>
          </div>
        </div>
        <div className="bks-tier">
          <button className="bks-th items-center flex gap-4 justify-between text-left w-full">
            <span>
              <b>Level 3</b>
              <small>Sections 401–435 · 35 sections</small>
              <em>6 seats left</em>
            </span>
            <span className="pr text-right">
              <small>From</small>
              <b>KSh 15,000</b>
            </span>
            <i>⌄</i>
          </button>
          <div className="bks-pick hidden flex-wrap gap-[0.4rem] max-h-[160px] overflow-auto">
            <button disabled>401</button>
            <button disabled>402</button>
            <button disabled>403</button>
            <button disabled>404</button>
            <button>405</button>
            <button disabled>406</button>
            <button disabled>407</button>
            <button disabled>408</button>
            <button disabled>409</button>
            <button disabled>410</button>
            <button disabled>411</button>
            <button>412</button>
            <button>413</button>
            <button disabled>414</button>
            <button disabled>415</button>
            <button disabled>416</button>
            <button disabled>417</button>
            <button disabled>418</button>
            <button disabled>419</button>
            <button disabled>420</button>
            <button disabled>421</button>
            <button disabled>422</button>
            <button disabled>423</button>
            <button disabled>424</button>
            <button disabled>425</button>
            <button disabled>426</button>
            <button disabled>427</button>
            <button disabled>428</button>
            <button disabled>429</button>
            <button disabled>430</button>
            <button disabled>431</button>
            <button disabled>432</button>
            <button disabled>433</button>
            <button disabled>434</button>
            <button disabled>435</button>
          </div>
        </div>
        <div className="bks-tier">
          <button className="bks-th items-center flex gap-4 justify-between text-left w-full">
            <span>
              <b>Gold</b>
              <small>5 sections</small>
              <em>9 seats left</em>
            </span>
            <span className="pr text-right">
              <small>From</small>
              <b>KSh 20,000</b>
            </span>
            <i>⌄</i>
          </button>
          <div className="bks-pick hidden flex-wrap gap-[0.4rem] max-h-[160px] overflow-auto">
            <button>1</button>
            <button>2</button>
            <button>3</button>
            <button>4</button>
            <button disabled>5</button>
          </div>
        </div>
        <div className="bks-tier">
          <button className="bks-th items-center flex gap-4 justify-between text-left w-full">
            <span>
              <b>Platinum</b>
              <small>3 sections</small>
              <em>5 seats left</em>
            </span>
            <span className="pr text-right">
              <small>From</small>
              <b>KSh 45,000</b>
            </span>
            <i>⌄</i>
          </button>
          <div className="bks-pick hidden flex-wrap gap-[0.4rem] max-h-[160px] overflow-auto">
            <button>1</button>
            <button disabled>2</button>
            <button>3</button>
          </div>
        </div>
        <div className="bks-tier">
          <button className="bks-th items-center flex gap-4 justify-between text-left w-full">
            <span>
              <b>Skyboxes</b>
              <small>Boxes 301–350 · 50 sections</small>
              <em>33 seats left</em>
            </span>
            <span className="pr text-right">
              <small>From</small>
              <b>KSh 50,000</b>
            </span>
            <i>⌄</i>
          </button>
          <div className="bks-pick hidden flex-wrap gap-[0.4rem] max-h-[160px] overflow-auto">
            <button disabled>301</button>
            <button disabled>302</button>
            <button disabled>303</button>
            <button>304</button>
            <button>305</button>
            <button>306</button>
            <button disabled>307</button>
            <button disabled>308</button>
            <button disabled>309</button>
            <button>310</button>
            <button>311</button>
            <button>312</button>
            <button disabled>313</button>
            <button disabled>314</button>
            <button disabled>315</button>
            <button disabled>316</button>
            <button disabled>317</button>
            <button disabled>318</button>
            <button disabled>319</button>
            <button disabled>320</button>
            <button disabled>321</button>
            <button disabled>322</button>
            <button disabled>323</button>
            <button disabled>324</button>
            <button disabled>325</button>
            <button disabled>326</button>
            <button disabled>327</button>
            <button disabled>328</button>
            <button disabled>329</button>
            <button>330</button>
            <button>331</button>
            <button disabled>332</button>
            <button disabled>333</button>
            <button disabled>334</button>
            <button disabled>335</button>
            <button disabled>336</button>
            <button disabled>337</button>
            <button disabled>338</button>
            <button disabled>339</button>
            <button disabled>340</button>
            <button disabled>341</button>
            <button disabled>342</button>
            <button disabled>343</button>
            <button disabled>344</button>
            <button disabled>345</button>
            <button disabled>346</button>
            <button disabled>347</button>
            <button>348</button>
            <button disabled>349</button>
            <button>350</button>
          </div>
        </div>
      </div>
      <div className="bks-sum min-h-[1.2rem]" />
    </aside>
  );
}
