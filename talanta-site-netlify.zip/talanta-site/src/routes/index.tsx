import { useEffect } from "react";
import { createFileRoute } from "@tanstack/react-router";
import capturedCSS from "../styles/pages/index.css?raw";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [{ title: "Talanta Sports City - Talanta Sports City" }] }),
  staticData: { importedDocument: { html: { "lang": "en-US" }, body: {  } } },
  component: Index,
});

function Index() {
  useImportedLayout();
  return (
    <>
      <style>{capturedCSS}</style>
      <div className="wp-site-blocks">
        <div className="tsc isolate overflow-hidden relative w-screen" id="tsc">
          <header className="tsc-header" id="tscHeader" data-site-import-scroll-header={"{\"desktop\":{\"added\":[\"is-stuck\"],\"removed\":[],\"threshold\":648},\"mobile\":{\"added\":[\"is-stuck\"],\"removed\":[],\"threshold\":633}}"}>
            <div className="tsc-wrap tsc-header__in">
              <a className="tsc-brand" aria-label="Talanta Sports City home" href="/">{"\n        "}<img className="tsc-brand__logo" src="/site-assets/bdb07e1d3f59d410.png" alt="" width="156" height="42" />{"\n        "}<span className="tsc-brand__name">Talanta Sports City</span>{"\n      "}</a>
              <nav className="tsc-nav" id="tscNav" aria-label="Main"><a href="#match-info">Match info</a><a href="#about">About</a></nav>
              <div className="tsc-actions"><button className="tsc-theme" id="tscTheme" type="button" aria-label="Switch to light theme" aria-pressed="false">{"\n          "}<svg className="tsc-moon" viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" /></svg>{"\n          "}<svg className="tsc-sun" viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></svg>{"\n        "}</button><a className="tsc-btn tsc-btn--green" href="/events/bayern-munich-vs-ajax">Tickets</a><button className="tsc-burger" id="tscBurger" type="button" aria-label="Open menu" aria-expanded="false" aria-controls="tscNav"><span /><span /><span /></button></div>
            </div>
          </header>
          <section className="items-center flex min-h-svh relative" id="match-info">
            <div className="tsc-hero__bg inset-0 absolute -z-2" aria-hidden="true" />
            <div className="tsc-hero__shade inset-0 absolute -z-1" aria-hidden="true" />
            <div className="tsc-wrap tsc-hero__in">
              <div className="tsc-crests items-center flex gap-[30px]"><img src="/site-assets/e2b35c0380109ae7.webp" alt="FC Bayern München" width="126" height="126" /><span className="tsc-crests__rule w-px" aria-hidden="true" /><img src="/site-assets/2994cabf5b6cf650.webp" alt="AFC Ajax" width="126" height="126" /></div>
              <h1 className="tsc-title max-w-none! [@media(min-width:821px)]:whitespace-nowrap">Bayern Munich <br />vs Ajax</h1>
              <p className="tsc-meta grid gap-[6px]"><strong>Tue 5 Jan 2027 · Gates open at 11:00</strong><span>Raila Odinga International Stadium, Nairobi</span></p>
              <div className="items-start flex flex-col gap-[22px]">
                <a className="tsc-btn tsc-btn--white" href="/events/bayern-munich-vs-ajax" id="tickets">Buy tickets</a>
                <p className="tsc-price [@media(max-width:820px)]:text-center [@media(max-width:820px)]:w-full">From <strong>KSh 2,500</strong> per seat · <a href="/events/bayern-munich-vs-ajax">All prices</a></p>
              </div>
            </div>
          </section>
        </div>
        <div className="tsb overflow-hidden relative w-screen" id="tsb">
          <ImportedSectionRailaOdingaInternationalStadium />
          <ImportedSectionHospitality />
          <dialog className="tsb-dialog w-[min(520px,calc(100vw_-_32px))]" id="tsbDialog" aria-labelledby="tsbDlgTitle">
            <button className="tsb-dialog__x cursor-pointer absolute right-[14px] top-[10px]" type="button" aria-label="Close">×</button>
            <h3 className="tsb-card__title" id="tsbDlgTitle" />
            <p className="tsb-card__sub" id="tsbDlgSub" />
            <ul className="tsb-list grid gap-[14px] list-none" id="tsbDlgList" />
            <a className="tsb-btn items-center cursor-pointer gap-[14px] [@media(max-width:560px)]:justify-center" href="/events/bayern-munich-vs-ajax">Enquire or book</a>
          </dialog>
        </div>
        <ImportedFooterBuy />
      </div>
    </>
  );
}

function ImportedSectionRailaOdingaInternationalStadium() {
  return (
    <section className="tsb-sec" id="about">
      <div className="tsb-wrap tsb-stadium__grid items-center grid max-w-[1280px] w-full">
        <div>
          <p className="tsb-eyebrow">The stadium</p>
          <h2 className="tsb-h tsb-h--xl">Raila Odinga International Stadium</h2>
          <p className="tsb-lead max-w-[34em]">Welcome to the Raila Odinga International Stadium, a 60,000-seat venue built for the passion of sports and the energy of live entertainment. This is where Kenya’s sporting ambition meets the world.</p>
          <ul className="tsb-stats grid gap-[5px] list-none max-w-[720px]">
            <li>
              <strong>60,000</strong>
              <span>seats</span>
            </li>
            <li>
              <strong>Ngong Rd</strong>
              <span>Nairobi</span>
            </li>
            <li>
              <strong>AFCON</strong>
              <span>2027 co-host</span>
            </li>
          </ul>
          <a className="tsb-btn items-center cursor-pointer gap-[14px] [@media(max-width:560px)]:justify-center" href="/#/">About the Stadium
              <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M9 5l7 7-7 7" /></svg>{"\n        "}</a>
        </div>
        <div className="tsb-slider aspect-[4/3] overflow-hidden relative" id="tsbSlider" role="group" aria-roledescription="carousel" aria-label="Stadium photos">
          <div className="tsb-slide inset-0 opacity-0 absolute">
            <img src="/site-assets/ecd181e1174ae001.webp" alt="Inside Raila Odinga International Stadium" loading="lazy" />
          </div>
          <div className="tsb-slide inset-0 opacity-100 absolute">
            <img src="/site-assets/132a3c41b1618ede.webp" alt="Seating bowl and pitch" loading="lazy" />
          </div>
          <div className="tsb-slide inset-0 opacity-0 absolute">
            <img src="/site-assets/f80ee50c8187b965.webp" alt="Upper tier seating" loading="lazy" />
          </div>
          <div className="tsb-dots bottom-[14px] flex gap-[22px] justify-center left-0 absolute right-0" id="tsbDots">
            <button type="button" aria-label="Show photo 1" aria-current="false" />
            <button type="button" aria-label="Show photo 2" aria-current="true" />
            <button type="button" aria-label="Show photo 3" aria-current="false" />
          </div>
        </div>
      </div>
    </section>
  );
}

function ImportedSectionHospitality() {
  return (
    <section className="tsb-sec tsb-hosp" id="hospitality">
      <div className="tsb-wrap max-w-[1280px] w-full">
        <h2 className="tsb-h tsb-h--md">Hospitality</h2>
        <div className="tsb-cards grid gap-[20px]">
          <article className="tsb-card flex flex-col">
            <div className="tsb-card__img aspect-[16/10] overflow-hidden relative">
              <img src="/site-assets/33ee2721f8982bd6.webp" alt="" loading="lazy" />
              <span className="tsb-badge left-[16px] absolute top-[16px]">Gold</span>
            </div>
            <div className="tsb-card__body flex flex-1 flex-col">
              <h3 className="tsb-card__title">Gold</h3>
              <p className="tsb-card__sub">Hospitality sections F01–F05</p>
              <p className="tsb-card__lead">Elevated Match-Day Hospitality</p>
              <ul className="tsb-list grid gap-[14px] list-none">
                <li>VIP entrance into Raila Odinga International Stadium</li>
                <li>Access to the Gold Hospitality Suite within the stadium.</li>
              </ul>
              <div className="tsb-card__foot items-end flex gap-[16px] justify-between"><span /><button className="tsb-btn tsb-btn--sm items-center cursor-pointer gap-[14px] [@media(max-width:560px)]:justify-center" type="button">What you get</button></div>
            </div>
          </article>
          <article className="tsb-card flex flex-col">
            <div className="tsb-card__img aspect-[16/10] overflow-hidden relative">
              <img src="/site-assets/33ee2721f8982bd6.webp" alt="" loading="lazy" />
              <span className="tsb-badge left-[16px] absolute top-[16px]">Platinum</span>
            </div>
            <div className="tsb-card__body flex flex-1 flex-col">
              <h3 className="tsb-card__title">Platinum</h3>
              <p className="tsb-card__sub">Level 2 · main stand</p>
              <p className="tsb-card__lead">Premium Match-Day Hospitality</p>
              <ul className="tsb-list grid gap-[14px] list-none">
                <li>Exclusive VIP entrance into Raila Odinga International Stadium</li>
                <li>Access to the Platinum Hospitality Lounge within the stadium.</li>
              </ul>
              <div className="tsb-card__foot items-end flex gap-[16px] justify-between"><span className="tsb-price grid gap-[2px]"><small>On sale now</small><b>Per seat</b></span><button className="tsb-btn tsb-btn--sm items-center cursor-pointer gap-[14px] [@media(max-width:560px)]:justify-center" type="button">What you get</button></div>
            </div>
          </article>
          <article className="tsb-card flex flex-col">
            <div className="tsb-card__img aspect-[16/10] overflow-hidden relative">
              <img src="/site-assets/33ee2721f8982bd6.webp" alt="" loading="lazy" />
              <span className="tsb-badge left-[16px] absolute top-[16px]">Whole box</span>
            </div>
            <div className="tsb-card__body flex flex-1 flex-col">
              <h3 className="tsb-card__title">Skybox</h3>
              <p className="tsb-card__sub tsb-card__sub--gap">Level 2 · boxes round the stadium</p>
              <ul className="tsb-list grid gap-[14px] list-none">
                <li>Your own box, sold whole</li>
                <li>Every seat in it is yours</li>
              </ul>
              <div className="tsb-card__foot items-end flex gap-[16px] justify-between"><span className="tsb-price grid gap-[2px]"><b>Booked by e-mail</b></span><button className="tsb-btn tsb-btn--sm items-center cursor-pointer gap-[14px] [@media(max-width:560px)]:justify-center" type="button">What you get</button></div>
            </div>
          </article>
        </div>
      </div>
    </section>
  );
}

function ImportedFooterBuy() {
  return (
    <footer className="tsf isolate overflow-hidden" id="tsf">
      <div className="tsf-wrap max-w-[1832px] w-full">
        <div className="tsf-brand">
          <img className="tsf-logo block w-[clamp(240px,22.4vw,410px)]" loading="lazy" src="/site-assets/bdb07e1d3f59d410.png" alt="" width="410" height="110" />
          <p className="tsf-name">Talanta Sports City</p>
        </div>
        <nav className="tsf-cols grid" aria-label="Footer">
          <div>
            <h2 className="tsf-h">Buy</h2>
            <ul>
              <li>
                <a href="/">Match info</a>
              </li>
            </ul>
          </div>
          <div>
            <h2 className="tsf-h">Help</h2>
            <ul>
              <li>
                <a href="/">About the Stadium</a>
              </li>
              <li>
                <a href="/">My tickets</a>
              </li>
              <li>
                <a href="/">Frequently Asked Questions</a>
              </li>
              <li>
                <a href="/">Help and contact</a>
              </li>
              <li>
                <a href="/">Getting there</a>
              </li>
              <li>
                <a href="/">Log in</a>
              </li>
            </ul>
          </div>
          <div>
            <h2 className="tsf-h">Legal</h2>
            <ul>
              <li>
                <a href="/">Ticketing and Admission Terms</a>
              </li>
              <li>
                <a href="/">Terms of Use</a>
              </li>
              <li>
                <a href="/">Privacy Policy</a>
              </li>
            </ul>
          </div>
          <div>
            <h2 className="tsf-h">Contact</h2>
            <ul>
              <li>
                <a href="/">Contact us</a>
              </li>
              <li>
                <a href="mailto:info@talantasportscity.com">info@talantasportscity.com</a>
              </li>
              <li className="tsf-muted tsf-tight">Ngong Rd, Nairobi</li>
            </ul>
          </div>
        </nav>
        <ul className="tsf-trust grid gap-[32px]">
          <li>
            <svg viewBox="0 0 48 64" width="50" height="62" aria-hidden="true">
              <path d="M24 4L6 10v20c0 14 8 24 18 30 10-6 18-16 18-30V10z" fill="var(--tsf-mint)" />
              <path d="M15 31l7 7 12-14" fill="none" stroke="#0a090c" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <div>
              <b>Official ticket seller</b>
              <span>for Bayern Munich vs Ajax at Talanta</span>
            </div>
          </li>
          <li>
            <svg viewBox="0 0 48 64" width="50" height="62" aria-hidden="true">
              <path d="M14 28v-8a10 10 0 0 1 20 0v8" fill="none" stroke="var(--tsf-mint)" strokeWidth="5" />
              <rect x="5" y="28" width="38" height="32" rx="3" fill="var(--tsf-mint)" />
              <circle cx="24" cy="43" r="4.5" fill="#0a090c" />
            </svg>
            <div>
              <b>Secure mobile money and card</b>
              <span>Card details never touch this site</span>
            </div>
          </li>
          <li>
            <svg viewBox="0 0 64 48" width="62" height="50" aria-hidden="true">
              <path d="M2 6h60v13a5 5 0 0 0 0 10v13H2V29a5 5 0 0 0 0-10z" fill="var(--tsf-mint)" />
              <g fill="#0a090c">
                <circle cx="40" cy="13" r="2" />
                <circle cx="40" cy="24" r="2" />
                <circle cx="40" cy="35" r="2" />
              </g>
            </svg>
            <div>
              <b>Secure tickets</b>
              <span>By SMS and e-mail, and under My tickets</span>
            </div>
          </li>
        </ul>
        <div className="tsf-bottom flex gap-[24px] justify-between [@media(max-width:560px)]:flex-col">
          <p>© <span id="tsfYear">2026</span> Talanta Sports City · Ngong Rd, Nairobi.</p>
          <ul className="tsf-social flex gap-[12px]" aria-label="Social media">
            <li>
              <a aria-label="Instagram" href="/">
                <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="3" y="3" width="18" height="18" rx="5" />
                  <circle cx="12" cy="12" r="4" />
                  <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
                </svg>
              </a>
            </li>
            <li>
              <a aria-label="X" href="/">
                <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                </svg>
              </a>
            </li>
            <li>
              <a aria-label="TikTok" href="/">
                <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
                  <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z" />
                </svg>
              </a>
            </li>
            <li>
              <a aria-label="YouTube" href="/">
                <svg viewBox="0 0 24 24" width="28" height="28" fill="currentColor">
                  <rect x="1.5" y="4.5" width="21" height="15" rx="4.5" />
                  <path d="M10 8.7l5 3.3-5 3.3z" fill="#1b1a1f" />
                </svg>
              </a>
            </li>
            <li>
              <a aria-label="Facebook" href="/">
                <svg viewBox="0 0 24 24" width="26" height="26" fill="currentColor">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                </svg>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </footer>
  );
}


function useImportedLayout() {
  useEffect(() => {
    const scrollingAreas = Array.from(document.querySelectorAll<HTMLElement>("[data-site-import-scroll-root]"));
    const scrollTop = () =>
      scrollingAreas.find(
        (node) =>
          node.clientHeight > 0 &&
          node.scrollHeight > node.clientHeight &&
          /^(auto|scroll)$/.test(getComputedStyle(node).overflowY),
      )?.scrollTop ?? window.scrollY;
    const scrollHeaders = Array.from(document.querySelectorAll<HTMLElement>("[data-site-import-scroll-header]"))
      .slice(0, 128)
      .flatMap((node) => {
        try {
          const states = JSON.parse(node.dataset["siteImportScrollHeader"] || "{}");
          if (!states || typeof states !== "object") return [];
          for (const key of ["desktop", "mobile"]) {
            const state = states[key];
            if (
              !state ||
              !Array.isArray(state.added) ||
              !Array.isArray(state.removed) ||
              state.added.length + state.removed.length > 32
            )
              delete states[key];
          }
          return [
            {
              node,
              states,
              original: new Set(node.classList),
              originalFill: node.getAttribute("fill"),
              transform: node.style.getPropertyValue("transform"),
              priority: node.style.getPropertyPriority("transform"),
            },
          ];
        } catch {
          return [];
        }
      });
    function syncScrollHeaders(reset = false) {
      for (const { node, states, original, originalFill, transform, priority } of scrollHeaders) {
        if (!reset && node.getAttribute("data-import-menu-open") === "true") continue;
        const state = states[innerWidth < 768 ? "mobile" : "desktop"];
        if ([states.desktop, states.mobile].some((entry) => entry && Object.hasOwn(entry, "fill"))) {
          if (originalFill === null) node.removeAttribute("fill");
          else node.setAttribute("fill", originalFill);
        }
        if (states.desktop?.transform || states.mobile?.transform) {
          if (transform) node.style.setProperty("transform", transform, priority);
          else node.style.removeProperty("transform");
        }
        for (const value of [states.desktop, states.mobile].filter(Boolean) as {
          added: string[];
          removed: string[];
        }[]) {
          for (const token of [...(value.added || []), ...(value.removed || [])]) {
            if (typeof token !== "string" || !token || /\s/.test(token)) continue;
            node.classList.toggle(token, original.has(token));
          }
        }
        if (reset || !state || !Number.isFinite(state.threshold) || scrollTop() < state.threshold) continue;
        let until = state.until;
        if (
          typeof state.untilAnchor === "string" &&
          /^\d$/.test(state.untilAnchor) &&
          Number.isFinite(state.untilProgress) &&
          Math.abs(state.untilProgress) <= 2
        ) {
          const anchor = document.querySelector<HTMLElement>(
            '[data-site-import-header-end="' + state.untilAnchor + '"]',
          );
          if (anchor) until = anchor.getBoundingClientRect().top + scrollTop() + innerHeight * state.untilProgress;
        }
        if (Number.isFinite(until) && scrollTop() >= until) continue;
        if (state.fill === null) node.removeAttribute("fill");
        else if (typeof state.fill === "string" && state.fill.length <= 256 && !/url\(/i.test(state.fill))
          node.setAttribute("fill", state.fill);
        if (
          typeof state.transform === "string" &&
          state.transform.length <= 128 &&
          CSS.supports("transform", state.transform)
        )
          node.style.setProperty("transform", state.transform, "important");
        for (const token of state.added || [])
          if (typeof token === "string" && token && !/\s/.test(token)) node.classList.add(token);
        for (const token of state.removed || [])
          if (typeof token === "string" && token && !/\s/.test(token)) node.classList.remove(token);
      }
    }
    const handleScroll = () => {
      syncScrollHeaders();
    };
    function resizeSummaries() {
      syncScrollHeaders();
    }
    document.addEventListener("load", handleScroll, true);
    resizeSummaries();
    const parallaxFrame = requestAnimationFrame(handleScroll);
    window.addEventListener("resize", resizeSummaries);
    document.addEventListener("scroll", handleScroll, { passive: true, capture: true });
    return () => {
      cancelAnimationFrame(parallaxFrame);
      syncScrollHeaders(true);
      document.removeEventListener("load", handleScroll, true);
      window.removeEventListener("resize", resizeSummaries);
      document.removeEventListener("scroll", handleScroll, true);
    };
  }, []);
}
